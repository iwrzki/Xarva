<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang-->

<?php 
session_start(); // Pastikan sesi dimulai

// Nama cookie untuk sesi
$cookie_name = 'SESSION_TOKEN';

// Periksa jika ada token sesi di cookie
$session_token = isset($_COOKIE[$cookie_name]) ? $_COOKIE[$cookie_name] : null;

// Jika sesi token tidak ada atau tidak valid
if (!$session_token || !isset($_SESSION[$session_token])) {
    // Tidak ada sesi yang valid, arahkan ke halaman utama
    header("Location: pages-login.php");
    exit();
}

// Periksa role pengguna
$role = isset($_SESSION[$session_token]['role']) ? $_SESSION[$session_token]['role'] : null;

// Jika role pengguna tidak sesuai dengan yang diizinkan (misalnya, hanya admin dan user yang dapat logout)
if ($role !== 'user' && $role !== 'admin') {
    // Role tidak valid, arahkan ke halaman utama
    header("Location: pages-login.php");
    exit();
}

// Hapus cookie dari browser jika ada
if ($session_token && isset($_COOKIE[$cookie_name])) {
    setcookie($cookie_name, '', time() - 3600, '/'); // Parameter keempat adalah path, pastikan ini sama dengan path saat Anda mengatur cookie
}

// Hapus data sesi
session_unset(); // Hapus semua data sesi

// Arahkan kembali ke halaman login atau halaman utama
header("Location: pages-login.php");
exit();
?>
