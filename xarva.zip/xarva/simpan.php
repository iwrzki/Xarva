<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php 
include 'config/koneksi.php';

if (isset($_POST['simpan'])) {
    $ID = $_POST['ID'];
    $Nama = $_POST['Nama'];
    $Notelp = $_POST['Notelp'];
    $role = $_POST['role'];
    $Email = $_POST['Email'];
    $Password = md5($_POST['Password']);
    $secret_key = isset($_POST['secret_key']) ? $_POST['secret_key'] : ''; // Menangkap kunci rahasia jika ada

    // Cek apakah nama pengguna sudah digunakan
    $cek = mysqli_query($conn, "SELECT * FROM user WHERE Nama='$Nama'");
    if (mysqli_num_rows($cek) > 0) {
        echo "
            <script>
            alert('Nama Pengguna Sudah Digunakan');
            window.location='pages-register.php';
            </script>
        ";
    } else {
        // Validasi role Admin dan kunci rahasia
        if ($role === 'admin') {
            // Ganti dengan kunci rahasia yang valid
            if ($secret_key !== 'xarvahore') {
                echo "
                    <script>
                    alert('Akses ditolak: Kunci rahasia tidak valid.');
                    window.location='pages-register.php';
                    </script>
                ";
                exit();
            }
        }

        // Insert data ke dalam tabel user
        $simpan = mysqli_query($conn, "INSERT INTO user (ID, Nama, Notelp, Email, Password, role) 
                                      VALUES ('$ID', '$Nama', '$Notelp', '$Email', '$Password', '$role')");

        if ($simpan) {
            echo "
                <script>
                alert('Berhasil Didaftar');
                window.location='pages-login.php';
                </script>
            ";
        } else {
            echo "
                <script>
                alert('Gagal Didaftar: " . mysqli_error($conn) . "');
                window.location='pages-register.php';
                </script>
            ";
        }
    }
}
?>
