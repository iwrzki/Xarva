<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang-->

<?php 
session_start();
include 'config/koneksi.php'; // Connection to the database

if (isset($_POST['masuk'])) {
    $Email = mysqli_real_escape_string($conn, $_POST['Email']);
    $Password = md5($_POST['Password']);

    // Check in users table
    $panggil_user = mysqli_query($conn, "SELECT * FROM user WHERE Email = '$Email' AND Password = '$Password'");
    $cek_user = mysqli_num_rows($panggil_user);

    if ($cek_user > 0) {
        $pilih_user = mysqli_fetch_array($panggil_user);

        session_regenerate_id(true); 

        // Generate a unique session token
        $session_token = bin2hex(random_bytes(32));
        $role = $pilih_user['role'];

        // Store session token in session
        $_SESSION[$session_token] = [
            'ID' => $pilih_user['ID'],
            'Nama' => $pilih_user['Nama'],
            'Notelp' => $pilih_user['Notelp'],
            'Email' => $pilih_user['Email'],
            'role' => $role
        ];

        // Set a cookie with the session token
        setcookie('SESSION_TOKEN', $session_token, time() + 3600, '/'); // Expires in 1 hour

        if ($role == 'admin') {
            echo "<script>alert('Berhasil Masuk sebagai Admin'); window.location.href = 'admin/index.php';</script>";
        } elseif ($role == 'user') {
            echo "<script>alert('Berhasil Masuk sebagai User'); window.location.href = 'user/indexstore.php';</script>";
        }
        exit();
    } else {
        echo "<script>alert('Gagal Masuk'); window.location.href = 'pages-login.php';</script>";
        exit();
    }
}
?>