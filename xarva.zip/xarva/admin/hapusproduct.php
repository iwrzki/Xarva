<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->

<?php
include '../config/koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM product WHERE id = ?");
    $stmt->bind_param("i", $id); // "i" indicates the type is integer

    if ($stmt->execute()) {
        header('Location: viewproduct.php?message=delete_success');
    } else {
        header('Location: viewproduct.php?message=delete_failed');
    }

    $stmt->close(); // Close the statement
}

$conn->close(); // Close the connection
?>
