<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php
session_start();

// Menyertakan file konfigurasi untuk koneksi database
include '../config/koneksi.php';

// Mengecek apakah form di-submit dengan metode POST
if (isset($_POST['update'])) {
    // Mengambil data dari form
    $id = $_POST['id'];
    $size = $_POST['size'];
    $amount = $_POST['amount'];
    $color = $_POST['color'];
    $price = $_POST['price'];
    $date = $_POST['date'];

    // Menyiapkan query SQL untuk memperbarui data produk
    $sql = mysqli_query($conn, "UPDATE product SET size='$size', amount='$amount', color='$color', price='$price', date='$date' WHERE id='$id'");

    // Mengecek apakah query berhasil
    if ($sql) {
        // Menampilkan alert jika update berhasil dan mengalihkan pengguna
        echo "
            <script>
                alert('Berhasil diupdate');
                window.location='viewproduct.php';
            </script>
        ";
    } else {
        // Menampilkan alert jika update gagal dan mengalihkan pengguna
        echo "
            <script>
                alert('Gagal diupdate: " . mysqli_error($conn) . "');
                window.location='viewproduct.php';
            </script>
        ";
    }
} else {
    // Menampilkan alert jika tidak ada data yang di-submit dan mengalihkan pengguna
    echo "
        <script>
            alert('Gagal diupdate');
            window.location='viewproduct.php';
        </script>
    ";
}
?>
