<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php 
include '../config/koneksi.php';

$s1 = $_POST['id'];
$s2 = $_POST['date'];
$s3 = $_POST['nameproduct'];
$s4 = $_POST['color'];
$s5 = $_POST['size'];
$s6 = $_POST['amount'];
$s8 = $_POST['price'];
$s7 = $_FILES['preview']['name'];
$tmp_s7 = $_FILES['preview']['tmp_name'];

// File upload path
$tempat = "../assets/img/" . $s7;

// Check if ID already exists
$cekid = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM product WHERE id='$s1'"));
if ($cekid) {
    echo "
        <script>
        alert('ID already used');
        window.location='input.php';
        </script>
    ";
} else {
    // Attempt to move the uploaded file
    if (move_uploaded_file($tmp_s7, $tempat)) {
        // Insert data into the database
        $simpan = mysqli_query($conn, "INSERT INTO product (id, date, nameproduct, color, size, amount, price, preview) VALUES ('$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s8', '$s7')");

        if ($simpan) {
            echo "
                <script>
                alert('Successfully registered');
                window.location='viewproduct.php';
                </script>
            ";
        } else {
            echo "
                <script>
                alert('Failed to register');
                window.location='inputproduct.php';
                </script>
            ";
        }
    } else {
        echo "
            <script>
            alert('Failed to upload file');
            window.location='inputproduct.php';
            </script>
     ";
}
}
?>