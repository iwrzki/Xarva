<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php
session_start();
include '../config/koneksi.php'; // Connection to the database

// Retrieve session token from cookie
$session_token = isset($_COOKIE['SESSION_TOKEN']) ? $_COOKIE['SESSION_TOKEN'] : null;

if (!$session_token || !isset($_SESSION[$session_token]) || $_SESSION[$session_token]['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Retrieve admin data from session
$admin = $_SESSION[$session_token];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Costumer-Data</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="../assets/img/logo2.jpg" rel="icon">
    <link href="../assets/img/logo1.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">
        <div class="d-flex align-items-center justify-content-between">
            <a href="index.php" class="logo d-flex align-items-center">
                <img src="../assets/img/logo1.png" alt="">
                <span class="d-none d-lg-block">XARVA</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div><!-- End Logo -->

        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

                <!-- Profile -->
                <li class="nav-item dropdown pe-3">
                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($admin['Nama']); ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?= htmlspecialchars($admin['Nama']); ?></h6>
                            <span><?= htmlspecialchars($admin['ID']); ?></span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="profile-admin.php">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="../keluar.php">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">
        <ul class="sidebar-nav" id="sidebar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-layout-text-window-reverse"></i><span>Product</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="tables-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
                    <li>
                        <a href="inputproduct.php">
                            <i class="bi bi-circle"></i><span>Input Product</span>
                        </a>
                    </li>
                    <li>
                        <a href="viewproduct.php">
                            <i class="bi bi-circle"></i><span>View Products</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="datacustomer.php">
                    <i class="bi bi-shop"></i>
                    <span>Customer Data</span>
                </a>
            </li>
        </ul>
    </aside><!-- End Sidebar -->

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Customer Data</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Data Product</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Print</th>
                            <th scope="col">No Resi</th>
                            <th scope="col">Nama Penerima</th>
                            <th scope="col">Nama Product</th>
                            <th scope="col">Warna</th>
                            <th scope="col">Jumlah</th>
                            <th scope="col">Ukuran</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">No Tlp</th>
                            <th>Hapus</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Mengambil data dari tabel produk
                            $panggil = mysqli_query($conn, "SELECT * FROM chekout");
                            while ($tampil = mysqli_fetch_assoc($panggil)) {
                                $idco = $tampil['idco'];
                                $namaco= $tampil['namaco'];
                                $nameproduct = $tampil['nameproduct'];
                                $warna = $tampil['warna'];
                                $jumlah= $tampil['jumlah'];
                                $ukuran = $tampil['ukuran'];
                                $address = $tampil['address'];
                                $nohp = $tampil['nohp'];
                            ?>
                        <tr>
                            <td>
                                <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#basicModal"
                                    data-idco="<?= htmlspecialchars($idco); ?>"& data-address="<?= htmlspecialchars($address); ?>"& data-nohp="<?= htmlspecialchars($nohp); ?>"& data-namaco="<?= htmlspecialchars($namaco); ?>"& data-nameproduct="<?= htmlspecialchars($nameproduct); ?>"& data-ukuran="<?= htmlspecialchars($ukuran); ?>"& data-total="<?= htmlspecialchars($total); ?>"& data-jumlah="<?= htmlspecialchars($jumlah); ?>"& data-warna="<?= htmlspecialchars($warna); ?>">
                                    <i class="bx bx-message-square-detail"></i>
                                </a>
                            </td>
                            <th><?= htmlspecialchars($idco); ?></th>
                            <td><?= htmlspecialchars($namaco); ?></td>
                            <td><?= htmlspecialchars($nameproduct); ?></td>
                            <td><?= htmlspecialchars($warna); ?></td>
                            <td><?= htmlspecialchars($jumlah); ?> pcs</td>
                            <td><?= htmlspecialchars($ukuran); ?></td>
                            <td><?= htmlspecialchars($address); ?></td>
                            <td><?= htmlspecialchars($nohp); ?></td>
                            <td>
                                <a href="hapusproduct.php?id=<?= $id; ?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                        <?php
                            }
                            ?>

                    </tbody>
                </table>
                <!-- End Table with hoverable rows -->

                <div class="modal fade" id="basicModal" tabindex="-1" aria-labelledby="basicModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="basicModalLabel">Nomor Resi</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p><strong>No Resi :</strong> <span id="resiNumber"></span></p>
                                <p><strong>Nama :</strong> <span id="namaco"></span></p>
                                <p><strong>No Tlp. :</strong> <span id="nohp"></span></p>
                                <p><strong>Address :</strong> <strong><span id="address"></span></strong></p>
                                <p><strong>Order :</strong> <span id="nameproduct"></span> <span id="warna"></span> Size (<span id="ukuran"></span>) <span id="jumlah"></span> pcs</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>goatmen</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="">goatmen</a>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/vendor/chart.js/chart.umd.js"></script>
    <script src="../assets/vendor/echarts/echarts.min.js"></script>
    <script src="../assets/vendor/quill/quill.js"></script>
    <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="../assets/vendor/php-email-form/validate.js"></script>
    <!-- Template Main JS File -->
    <script src="../assets/js/main.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var modalElement = document.getElementById('basicModal');
        modalElement.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget; // Button that triggered the modal
            var idco = button.getAttribute('data-idco'); // Extract info from data-* attributes
            var address = button.getAttribute('data-address');
            var nohp = button.getAttribute('data-nohp');
            var nameproduct = button.getAttribute('data-nameproduct');
            var ukuran = button.getAttribute('data-ukuran');
            var namaco = button.getAttribute('data-namaco');
            var warna = button.getAttribute('data-warna');
            var jumlah = button.getAttribute('data-jumlah');

            // Update the modal's content.
            var resiNumberSpan = document.getElementById('resiNumber');
            resiNumberSpan.textContent = idco; // Set the IDCO in the modal
            var addressSpan = document.getElementById('address');
            addressSpan.textContent = address; // Set the address in the modal
            var nohpSpan = document.getElementById('nohp');
            nohpSpan.textContent = nohp; // Set the address in the modal
            var nameproductSpan = document.getElementById('nameproduct');
            nameproductSpan.textContent = nameproduct; // Set the address in the modal
            var ukuranSpan = document.getElementById('ukuran');
            ukuranSpan.textContent = ukuran; // Set the address in the modal
            var namacoSpan = document.getElementById('namaco');
            namacoSpan.textContent = namaco; // Set the address in the modal
            var warnaSpan = document.getElementById('warna');
            warnaSpan.textContent = warna; // Set the address in the modal
            var jumlahSpan = document.getElementById('jumlah');
            jumlahSpan.textContent = jumlah; // Set the address in the modal
        });
    });
    </script>
</body>

</html>