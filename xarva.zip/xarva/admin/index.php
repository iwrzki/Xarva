<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php
session_start();
include '../config/koneksi.php'; // Connection to the database

// Retrieve session token from cookie
$session_token = isset($_COOKIE['SESSION_TOKEN']) ? $_COOKIE['SESSION_TOKEN'] : null;

if (!$session_token || !isset($_SESSION[$session_token]) || $_SESSION[$session_token]['role'] !== 'admin') {
    header("Location: ../pages-login.php");
    exit();
}

// Retrieve admin data from session
$admin = $_SESSION[$session_token];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Xarva-Admin</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="../assets/img/logo2.jpg" rel="icon">
    <link href="../assets/img/logo1.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">
        <div class="d-flex align-items-center justify-content-between">
            <a href="index.php" class="logo d-flex align-items-center">
                <img src="../assets/img/logo1.png" alt="">
                <span class="d-none d-lg-block">XARVA</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div><!-- End Logo -->

        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

                <!-- Profile -->
                <li class="nav-item dropdown pe-3">
                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <span class="d-none d-md-block dropdown-toggle ps-2"><?= htmlspecialchars($admin['Nama']); ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?= htmlspecialchars($admin['Nama']); ?></h6>
                            <span><?= htmlspecialchars($admin['ID']); ?></span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="profile-admin.php">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="../keluar.php">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">
        <ul class="sidebar-nav" id="sidebar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-layout-text-window-reverse"></i><span>Product</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="tables-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
                    <li>
                        <a href="inputproduct.php">
                            <i class="bi bi-circle"></i><span>Input Product</span>
                        </a>
                    </li>
                    <li>
                        <a href="viewproduct.php">
                            <i class="bi bi-circle"></i><span>View Products</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="datacustomer.php">
                    <i class="bi bi-shop"></i>
                    <span>Customer Data</span>
                </a>
            </li>
        </ul>
    </aside><!-- End Sidebar -->

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">
                <!-- Left side columns -->
                <div class="col-lg-8">
                    <div class="row">
                        <!-- Top Selling -->
                        <div class="col-12">
                            <div class="card top-selling overflow-auto">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Preview</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Color</th>
                                            <th scope="col">Size</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Retrieve product data
                                        $panggil = mysqli_query($conn, "SELECT * FROM product");
                                        while ($tampil = mysqli_fetch_assoc($panggil)) {
                                            $id = htmlspecialchars($tampil['id']);
                                            $preview = htmlspecialchars($tampil['preview']); // File name
                                            $nameproduct = htmlspecialchars($tampil['nameproduct']);
                                            $color = htmlspecialchars($tampil['color']);
                                            $size = htmlspecialchars($tampil['size']);
                                            $amount = htmlspecialchars($tampil['amount']);
                                            $price = number_format($tampil['price'], 0, ',', '.'); // Format price
                                            $date = htmlspecialchars($tampil['date']);
                                        ?>
                                        <tr>
                                            <th scope="row"><?= $id; ?></th>
                                            <td><img src="../assets/img/<?= $preview; ?>" alt="" style="max-width:100px; height:auto;"></td>
                                            <td><?= $nameproduct; ?></td>
                                            <td><?= $color; ?></td>
                                            <td><?= $size; ?></td>
                                            <td><?= $amount; ?></td>
                                            <td>Rp. <?= $price; ?></td>
                                            <td><?= $date; ?></td>
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- End Top Selling -->
                    </div>
                </div><!-- End Left side columns -->

                <!-- Right side columns -->
                <div class="col-lg-4">
                    <!-- Sales Card -->
                    <div class="col-12">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title">Stok <span>| Today</span></h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-archive-fill"></i>
                                    </div>
                                    <div class="ps-3">
                                        <?php
                                        // Query to count total products
                                        $sql = "SELECT SUM(amount) AS total_products FROM product";
                                        $result = $conn->query($sql);
                                        $totalProducts = $result->num_rows > 0 ? $result->fetch_assoc()['total_products'] : 0;
                                        ?>
                                        <h6><?= $totalProducts; ?></h6>
                                    </div>
                                </div>
                            </div>

                            <?php
                            // Query to count specific product types
                            $productTypes = ['T-Shirt', 'Hoodie', 'Sweatpants'];
                            $productCounts = [];
                            foreach ($productTypes as $type) {
                                $sql = "SELECT SUM(amount) AS total FROM product WHERE nameproduct = '$type'";
                                $result = $conn->query($sql);
                                $total = $result->num_rows > 0 ? $result->fetch_assoc()['total'] : 0;
                                $productCounts[$type] = $total;
                            }
                            ?>

                            <div class="card-body">
                                <!-- Radial Bar Chart -->
                                <div id="radialBarChart"></div>

                                <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
                                <script>
                                    document.addEventListener("DOMContentLoaded", () => {
                                        new ApexCharts(document.querySelector("#radialBarChart"), {
                                            series: [
                                                <?= $productCounts['T-Shirt']; ?>,
                                                <?= $productCounts['Hoodie']; ?>,
                                                <?= $productCounts['Sweatpants']; ?>
                                            ],
                                            chart: {
                                                height: 350,
                                                type: 'radialBar',
                                                toolbar: {
                                                    show: true
                                                }
                                            },
                                            plotOptions: {
                                                radialBar: {
                                                    dataLabels: {
                                                        name: {
                                                            fontSize: '22px',
                                                        },
                                                        value: {
                                                            fontSize: '16px',
                                                        },
                                                        total: {
                                                            show: true,
                                                            label: 'Total',
                                                            formatter: function(w) {
                                                                // Show the sum of all series
                                                                return <?= array_sum($productCounts); ?>;
                                                            }
                                                        }
                                                    }
                                                }
                                            },
                                            labels: ['T-Shirt', 'Hoodie', 'Sweatpants'],
                                        }).render();
                                    });
                                </script>
                                <!-- End Radial Bar Chart -->
                            </div>
                        </div>
                    </div><!-- End Sales Card -->

                    <!-- Donut Chart -->
                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Data Customer</h5>

                                <?php
                                // Ambil data dari database
                                $panggil = mysqli_query($conn, "SELECT nameproduct, SUM(jumlah) as total FROM chekout GROUP BY nameproduct");
                                $data = [];

                                while ($tampil = mysqli_fetch_assoc($panggil)) {
                                    $data[] = [
                                        'name' => $tampil['nameproduct'],
                                        'value' => (int) $tampil['total']
                                    ];
                                }

                                // Encode data sebagai JSON
                                echo '<script>';
                                echo 'var chartData = ' . json_encode($data) . ';';
                                echo '</script>';
                                ?>

                                <!-- Donut Chart -->
                                <div id="donutChart" style="min-height: 400px;" class="echart"></div>

                                <script src="https://cdn.jsdelivr.net/npm/echarts/dist/echarts.min.js"></script>
                                <script>
                                    document.addEventListener("DOMContentLoaded", () => {
                                        var chartData = <?php echo json_encode($data); ?>;
                                        
                                        echarts.init(document.querySelector("#donutChart")).setOption({
                                            tooltip: {
                                                trigger: 'item'
                                            },
                                            legend: {
                                                top: '5%',
                                                left: 'center'
                                            },
                                            series: [{
                                                name: 'Data Customer',
                                                type: 'pie',
                                                radius: ['40%', '70%'],
                                                avoidLabelOverlap: false,
                                                label: {
                                                    show: false,
                                                    position: 'center'
                                                },
                                                emphasis: {
                                                    label: {
                                                        show: true,
                                                        fontSize: '18',
                                                        fontWeight: 'bold'
                                                    }
                                                },
                                                labelLine: {
                                                    show: false
                                                },
                                                data: chartData
                                            }]
                                        });
                                    });
                                </script>
                                <!-- End Donut Chart -->
                            </div>
                        </div>
                    </div>
                </div><!-- End Right side columns -->
            </div>
        </section>
    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>goatmen</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="">goatmen</a>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/vendor/chart.js/chart.umd.js"></script>
    <script src="../assets/vendor/echarts/echarts.min.js"></script>
    <script src="../assets/vendor/quill/quill.js"></script>
    <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="../assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
