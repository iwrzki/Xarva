<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php
session_start();
include '../config/koneksi.php'; // Connection to the database

$session_token = isset($_COOKIE['SESSION_TOKEN']) ? $_COOKIE['SESSION_TOKEN'] : null;

if (!$session_token || !isset($_SESSION[$session_token]) || $_SESSION[$session_token]['role'] !== 'user') {

    header("Location: ../pages-login.php");
    exit();
}
$user = $_SESSION[$session_token];

if (isset($_GET['nameproduct'])) {
    $nameproduct = $_GET['nameproduct'];
    $price = $_GET['price'];

    $Nama = $user['Nama'];
    $Notelp = $user['Notelp'];
    
    // Cek dan ambil ID terakhir dari tabel checkout
    $query = mysqli_query($conn, "SELECT idco FROM chekout ORDER BY idco DESC LIMIT 1");
    if (mysqli_num_rows($query) > 0) {
        $row = mysqli_fetch_assoc($query);
        $lastidco = $row['idco'];
        $lastNumber = intval(substr($lastidco, 6)) + 1;
    } else {
        $lastNumber = 1;
    }
    
    // Tetapkan ID checkout
    $idco = 'XARVA-' . str_pad($lastNumber, 3, '0', STR_PAD_LEFT);
    
    // Simpan ID checkout dalam session
    $_SESSION['idco'] = $idco;



} else {
    echo "<script>alert('Pilih Nama Product Terlebih Dahulu'); 
    window.location='indexstore.php';
    </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Xarva-Admin</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="../assets/img/logo2.jpg" rel="icon">
    <link href=".../assets/img/logo1.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">

</head>

<body>
    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">
        <div class="d-flex align-items-center justify-content-between">
            <a href="indexstore.php" class="logo d-flex align-items-center">
                <img src="../assets/img/logo1.png" alt="">
                <span class="d-none d-lg-block">XARVA</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div><!-- End Logo -->

        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">
                <li class="nav-item dropdown pe-3">
                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <span
                            class="d-none d-md-block dropdown-toggle ps-2"><?php echo htmlspecialchars($user['Nama']); ?></span>
                    </a><!-- End Profile Iamge Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?php echo htmlspecialchars($user['Nama']); ?></h6>
                            <span><?php echo htmlspecialchars($user['ID']); ?></span>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="profile-user.php">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="../keluar.php">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    </ul><!-- End Profile Dropdown Items -->
                </li><!-- End Profile Nav -->
            </ul>
        </nav><!-- End Icons Navigation -->
    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">
        <ul class="sidebar-nav" id="sidebar-nav">
            <li class="nav-item">
                <a class="nav-link " href="indexstore.php">
                    <i class="bi bi-grid"></i>
                    <span>Store</span>
                </a>
            </li><!-- End Dashboard Nav -->
        </ul>
    </aside><!-- End Sidebar-->

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>T-Shirt</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="indexstore.php">Home</a></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="card mb-3">
                    <div class="row g-0">
                        <div class="col-md-8">
                            <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src="../assets/img/blackt.jpg" class="d-block w-100" alt="Black T-Shirt">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="../assets/img/darkgreen.jpg" class="d-block w-100"
                                            alt="Dark Green T-Shirt">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="../assets/img/blue.jpg" class="d-block w-100" alt="Blue T-Shirt">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card-body">
                                <h5 class="card-title">Basic T-Shirt</h5>
                                <h3>Rp 100.000</h3>
                                <!-- Size Selection -->
                                <form action="checkout.php" method="POST">
                                    <div class="mb-3">
                                        <input type="text" name="nameproduct" class="form-control" id="yourName"
                                        value="<?php echo isset($nameproduct) ? htmlspecialchars($nameproduct) : ''; ?>" hidden >
                                    </div>
                                    <fieldset class="row mb-3">
                                        <legend class="col-form-label col-sm-2 pt-0">Size</legend>
                                        <div class="col-sm-10">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="ukuran" id="sizeS"
                                                    value="S" required>
                                                <label class="form-check-label" for="sizeS">
                                                    S
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="ukuran" id="sizeM"
                                                    value="M" required>
                                                <label class="form-check-label" for="sizeM">
                                                    M
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="ukuran" id="sizeL"
                                                    value="L" required>
                                                <label class="form-check-label" for="sizeL">
                                                    L
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="ukuran" id="sizeXL"
                                                    value="XL" required>
                                                <label class="form-check-label" for="sizeXL">
                                                    XL
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="ukuran" id="sizeXXL"
                                                    value="XXL" required>
                                                <label class="form-check-label" for="sizeXXL">
                                                    XXL
                                                </label>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <div class="mb-3">
                                        <label for="colorSelect" class="form-label">Color</label>
                                        <select id="colorSelect" name="warna" class="form-select form-select-sm"
                                            style="width: auto;">
                                            <option value="Black">Black</option>
                                            <option value="Darkgreen">Dark Green</option>
                                            <option value="Blue">Blue</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="colorSelect" class="form-label">Quantity</label>
                                        <input type="number" name="jumlah" id="qty"
                                            class="form-control form-control-sm text-center" style="width: 60px;"
                                            min="1" value="1">
                                    </div>
                                    <div class="mb-3">
                                        <label for="" class="form-label">ID CheckOut</label>
                                        <input type="text" name="idco" class="form-control" id="idco"
                                            value="<?php echo isset($_SESSION['idco']) ? $_SESSION['idco'] : ''; ?>"
                                            readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="yourEmail" class="form-label">Nama Penerima</label>
                                        <input type="text" name="namaco" class="form-control" id="yourName"
                                            value=" <?php echo isset($Nama) ? $Nama : ''; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="inputPassword" class="col-sm-3 col-form-label">
                                            Address</label>
                                        <div class="col-sm-13">
                                            <textarea class="form-control" name="address"
                                                style="height: 100px"></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="yourUsername" class="form-label">Phone
                                                number</label>
                                            <div class="input-group has-validation">
                                                <span class="input-group-text" id="inputGroupPrepend">+62</span>
                                                <input type="text" name="nohp" class="form-control" id="yourPhoneNumber"
                                                    value=" <?php echo isset($Notelp) ? $Notelp : ''; ?>" required>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="" class="form-label">Total</label>
                                            <input type="text" name="total" class="form-control" id="total" required>
                                        </div>
                                        <div class="mb-3">
                                            <div class="col-sm-10">
                                                <button type="submit" class="btn btn-outline-danger" name="checkout">
                                                    <i class="bi bi-bag-check"></i> Check Out
                                                </button>
                                            </div>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>
    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>goatmen</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a
                href="">goatmen</a>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/vendor/chart.js/chart.umd.js"></script>
    <script src="../assets/vendor/echarts/echarts.min.js"></script>
    <script src="../assets/vendor/quill/quill.js"></script>
    <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="../assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="../assets/js/main.js"></script>
    <script>
    function calculateTotal() {
        let qty = parseInt(document.getElementById('qty').value, 10);
        let price = <?php echo $price; ?>;
        let totalprice = qty * price;

        totalprice = Math.round(totalprice);

        // Simpan nilai total biaya di input total
        document.getElementById('total').value = totalprice;
    }

    document.addEventListener('DOMContentLoaded', function() {
        calculateTotal();
        document.getElementById('qty').addEventListener('input', calculateTotal)
    });
    </script>

</body>

</html>