<!--(10123344) Muhammad Farhan Al-Ghifari: Perancang dan mengembangkan-->
<!--(10123323) Moch. Iwarizkianto Adiwijaya: Membantu dalam merancang mengimplementasikan fitur-->

<?php 
include '../config/koneksi.php';
session_start();

if (isset($_POST['checkout'])) {
    $idco = $_SESSION['idco']; // Ambil ID checkout dari session
    $namaco = $_POST['namaco'];
    $nameproduct = $_POST['nameproduct'];
    $warna = $_POST['warna'];
    $jumlah = $_POST['jumlah'];
    $ukuran = $_POST['ukuran'];
    $address = $_POST['address'];
    $nohp = $_POST['nohp'];
    $total = $_POST['total'];

    // Cek jika ID Checkout sudah ada
    $cek = mysqli_query($conn, "SELECT * FROM chekout WHERE idco='$idco'");
    if (mysqli_num_rows($cek) > 0) {
        echo "
            <script>
                alert('Id CheckOut sudah ada');
                window.location='indexstore.php';
            </script>
        ";
    } else {
        // Cek jumlah stok yang tersedia
        $stokQuery = mysqli_query($conn, "SELECT amount FROM product 
                                          WHERE nameproduct = '$nameproduct' 
                                          AND color = '$warna' 
                                          AND size = '$ukuran'");
        if (mysqli_num_rows($stokQuery) > 0) {
            $stokRow = mysqli_fetch_assoc($stokQuery);
            $availableAmount = $stokRow['amount'];

            if ($jumlah > $availableAmount) {
                echo "
                    <script>
                        alert('Barang habis');
                        window.location='indexstore.php';
                    </script>
                ";
            } else {
                // Insert data ke dalam tabel checkout
                $simpan = mysqli_query($conn, "INSERT INTO chekout (idco, namaco, nameproduct, warna, jumlah, ukuran, address, nohp, total) 
                                              VALUES ('$idco', '$namaco', '$nameproduct', '$warna', '$jumlah', '$ukuran', '$address', '$nohp', '$total')");

                if ($simpan) {
                    // Kurangi qty di tabel product
                    $update = mysqli_query($conn, "UPDATE product 
                                                    SET amount = amount - '$jumlah' 
                                                    WHERE nameproduct = '$nameproduct' 
                                                    AND color = '$warna' 
                                                    AND size = '$ukuran'");

                    if ($update) {
                        echo "
                            <script>
                                alert('Berhasil Checkout');
                                window.location='indexstore.php';
                            </script>
                        ";
                    } else {
                        echo "
                            <script>
                                alert('Gagal Update Qty: " . mysqli_error($conn) . "');
                                window.location='indexstore.php';
                            </script>
                        ";
                    }
                } else {
                    echo "
                        <script>
                            alert('Gagal Checkout: " . mysqli_error($conn) . "');
                            window.location='indexstore.php';
                        </script>
                    ";
                }
            }
        } else {
            echo "
                <script>
                    alert('Produk tidak ditemukan');
                    window.location='indexstore.php';
                </script>
            ";
        }
    }
}
?>
